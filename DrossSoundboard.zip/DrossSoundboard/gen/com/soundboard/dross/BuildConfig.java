/** Automatically generated file. DO NOT MODIFY */
package com.soundboard.dross;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}